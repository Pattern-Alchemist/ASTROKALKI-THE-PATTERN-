# SEO Content OS Starter

This package includes:
- n8n workflow skeletons
- Supabase migration files
- Next.js starter scaffold

Suggested order:
1. Run Supabase migrations.
2. Wire API routes to Supabase queries/mutations.
3. Import n8n workflow skeletons and configure credentials.
4. Replace placeholder queries and prompts with your real logic.
