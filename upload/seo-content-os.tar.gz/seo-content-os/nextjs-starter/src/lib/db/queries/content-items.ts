export async function getContentBySlug(slug: string) {
  return {
    slug,
    title: `Draft page for ${slug}`,
    content_md: 'Connect this query to Supabase content_items.'
  };
}
